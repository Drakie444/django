from django.shortcuts import render, redirect
from .models import Cat
from .forms import CatForm

# Create your views here.
def home_page(response):
    return render(response, 'home.html', {})

def wyswietl(response):
    cats = Cat.objects.all()
    return render(response, 'wyswietl.html', {'cats': cats})


def dodaj(request):
    if request.method == 'POST':
        form = CatForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dodaj')
    else:
        form = CatForm()
    return render(request, 'dodaj.html', {'form': form})