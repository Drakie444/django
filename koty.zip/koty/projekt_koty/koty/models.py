from django.db import models

# Create your models here.
class Cat(models.Model):
    id = models.IntegerField(primary_key=True)
    imie = models.TextField()
    kolor = models.TextField()
    wiek = models.IntegerField()
    rasa = models.TextField()
    img = models.URLField(max_length=500, blank=True)
    